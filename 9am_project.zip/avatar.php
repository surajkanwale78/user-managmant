<?php include("header.php");?>
<?php 
if(isset($_SESSION['logintrue']))
{
	$token=$_SESSION['logintrue'];
	
	$res=mysqli_query($con,"select profile_pic,username from users where token='$token'");
	$row=mysqli_fetch_assoc($res);
	?>
	<div class="container">
		<div class="row">
			<div class="col">
				<h1><?php echo $row['username']?> | Upload Avatar</h1>
				
				<?php 
				if($row['profile_pic']!="")
				{
				?>
					<img src='profiles/<?php echo $row['profile_pic']?>' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php }
				else
				{
					?>
					<img src='profiles/avatar.png' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php
				}
				?>
				
				<?php 
				if(isset($_COOKIE['success']))
				{
					echo $_COOKIE['success'];
				}
				
				if(isset($_POST['upload']))
				{
					if(is_uploaded_file($_FILES['profile']['tmp_name']))
					{
						$filename=$_FILES['profile']['name'];
						$type=$_FILES['profile']['type'];
						$tname=$_FILES['profile']['tmp_name'];
						
						$types=array(
						"image/png",
						"image/jpg",
						"image/jpeg",
						"image/gif",
						);
						
						$str="abcdefghijklmnopqrstuwxyz".time();
						
						$ext=substr(str_shuffle($str),5,15);
						$filename=$ext."_".$filename;
						
						if(in_array($type,$types))
						{
							move_uploaded_file($tname,"profiles/$filename");
							
							mysqli_query($con,"update users set profile_pic='$filename' where token='$token'");
							if(mysqli_affected_rows($con)>0)
							{
								setcookie("success","<p class='alert alert-success'>Avatar updated Succcessfully</p>",time()+2);
								header("Location:avatar.php");
							}
							else
							{
								echo "<p>Unable to update profile pic, try again</p>";
							}
							
							
						}
						else
						{
							echo "<p>Please select a valid image to uplaod</p>";
						}
					}
					else
					{
						echo "<p class='alert alert-danger'>Please select a file to upload</p>";
					}
				}
				?>
				
				<form method="POST" action="" enctype="multipart/form-data">
				
				Upload Avatar:<br>
				<input type="file" name="profile" class="form-control">
				
				<br><br>
				<input type="submit" name="upload" value="Uplaod" class="btn btn-primary">
					
				</form>
			</div>
		</div>
	</div>
	<?php
}
else
{
	header("Location:login.php");
}
?>
<?php include("footer.php");?>