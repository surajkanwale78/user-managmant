<?php include("header.php");?>

	<div class="container">
		<div class="row">
			<div class="col">
			<h1>Register Here</h1>
		
		<?php 
		//4th step
		if(isset($_POST['register']))
		{
			//4.1 collect the form data
			$uname=(isset($_POST['uname']))? $_POST['uname']:"";
			$email=(isset($_POST['email']))?$_POST['email']:"";
			$pwd=(isset($_POST['pass']))?$_POST['pass']:"";
			$mob=(isset($_POST['mobile']))?$_POST['mobile']:"";
			$gender=(isset($_POST['gender']))?$_POST['gender']:"";
			$terms=(isset($_POST['terms']))?$_POST['terms']:"";
			$state=(isset($_POST['state']))?$_POST['state']:"";
			$dob=(isset($_POST['dob']))?$_POST['dob']:"";
			$ip=$_SERVER['REMOTE_ADDR'];
			$token=md5(str_shuffle($uname.$email.$pwd.time()));
			
			$pwd=password_hash($pwd,PASSWORD_DEFAULT);
			
			//4.3 insert data into users tables
			
			mysqli_query($con,"insert into users(username,email,passowrd,mobile,gender,dob,state,terms,ip,token) values('$uname','$email','$pwd','$mob','$gender','$dob','$state','$terms','$ip','$token')");
			
			
			
			if(mysqli_affected_rows($con)>0)
			{
				$to=$email;
				$subject="Account Activation Link-GoPHP";
				$message="Hi ".$uname.",<br><br>Thanks for creating an account with us. Please activate your account by clicking the below link<br><br><a href='http://localhost:100/9am/activate.php?key=".$token."' target='_blank'>Activate Now</a><br><br>Thanks<br>Team";
				$headers="Content-Type:text/html";
				
				
				
				if(mail($to,$subject,$message,$headers))
				{
					echo "<p>Account created successfully. please activate your account</p>";
				}
				else
				{
					echo "<p>Account created successfully. unbale to send activation link. Contact admin</p>";
				}
			}
			else
			{
				echo mysqli_error($con);
				echo "<p>Sorry! Unable to Insert a record. Try again</p>";
			}
			
		}
		?>
		
		
		<form method="POST" action="" onsubmit="return validate()">
			<table class="table">
				<tr>
					<td>Username</td>
					<td><input type="text" name="uname" id="uname" class="form-control"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" class="form-control"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pass" id="pass" class="form-control"></td>
				</tr>
				<tr>
					<td>Confirm Password</td>
					<td><input type="password" name="cpass" class="form-control" id="cpass"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" class="form-control"></td>
				</tr>
				<tr>
					<td>DOB</td>
					<td><input type="text" name="dob" id="dob" placeholder="DD-MM-YYYY" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Gender</td>
					<td>
					<input type="radio" name="gender" value="male">Male
					<input type="radio" name="gender"valve="female">Female
					</td>
				</tr>
				
				<tr>
					<td>State</td>
					<td>
						<select id="state" name="state" class="form-control">
						<option value="">--State--</option>
						<option value="Andhrapradesh">Andhrapradesh</option>
						<option value="Telangana">Telangana</option>
						</select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="checkbox" name="terms" id="terms"  value="1">Please accept T&C</td>
				</tr>
					
				<tr>
					<td></td>
					<td><input type="submit" name="register" value="Register" class="btn btn-primary" ></td>
				</tr>
			</table>
		</form>
		
		<script>
		function validate()
		{
			
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
			//Email
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				return false;
			}
			else
			{
				var mail=document.getElementById("email").value;
				filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				
				
				if(!filter.test(mail))
				{
					alert("Enter Valid Email");
					return false;
				}
			}
			//Password validation
			if(document.getElementById("pass").value=="")
			{
				alert("Enter Password");
				return false;
			}
			if(document.getElementById("cpass").value=="")
			{
				alert("Enter Confirm Password");
				return false;
			}
			
			if(document.getElementById("pass").value!=document.getElementById("cpass").value)
			{
				alert("Passwords does not matched");
				return false;
			}
			//Mobile Validation
			if(document.getElementById("mobile").value=="")
			{
				alert("Enter Mobile Number");
				return false;
			}
			else
			{
				var mob=document.getElementById("mobile").value;
				var pat=/^[0]?[789]\d{9}$/;
				if(!pat.test(mob))
				{
					alert("Enter valid 10 digit mobile number");
					return false;
				}
			}
			
		}
		</script>
				
			
			</div>
		</div>
	</div>

<?php include("footer.php");?>