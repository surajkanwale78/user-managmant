<?php include("header.php");?>
	<div class="container">
		<div class="row">
			<div class="col">
				
				<h1>Login Here</h1>
		<?php 
		//4th step
		if(isset($_POST['login']))
		{
			$email=(isset($_POST['email']))? $_POST['email']: "";
			$pwd=(isset($_POST['pwd']))?$_POST['pwd']:"";
			
			$email=trim(strip_tags(addslashes($email)));
			$pwd=trim(strip_tags(addslashes($pwd)));
			
			//check the credentials
			$res=mysqli_query($con,"select *from users where email='$email'");
			
			if(mysqli_num_rows($res)==1)
			{
				$row=mysqli_fetch_assoc($res);
				if(password_verify($pwd,$row['passowrd']))
				{
					if($row['status']=="active")
					{
						$_SESSION['logintrue']=$row['token'];
						header("Location:home.php");
					}
					else
					{
						echo "<p>Please activate your account</p>";
					}
				}
				else
				{
					echo "<p class='alert alert-danger'>Wrong Password entered for email</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger'>Wrong email entered</p>";
			}
			
			
		}
		?>
		
		
		<form method="POST" action="" onsubmit="return validateLogin()">
			<table class="table">
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" class="form-control"></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pwd" id="pwd" class="form-control"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="login" value="Login" class="btn btn btn-primary">
					<a href="forgot.php">Forgot Password?</a>
					</td>
				</tr>
			</table>
		</form>
		<script>
			function validateLogin()
			{
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
				
				if(document.getElementById("pwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
			}                                                         
		</script>
			
			</div>
		</div>
	</div>
<?php include("footer.php");?>