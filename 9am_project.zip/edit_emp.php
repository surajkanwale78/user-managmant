<?php 
include("header.php");
if(isset($_REQUEST['token']))
{
	include("connect.php");
	$id=$_REQUEST['token'];
	$res=mysqli_query($con,"select *from employee where eid='$id'");
	if(mysqli_num_rows($res)==1)
	{
		$row=mysqli_fetch_assoc($res);
		?>
		
		<div class="container">
			<div class="row">
				<div class='col'>
					<h1>Edit Employee</h1>
		
		
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['update']))
		{
			$name=(isset($_POST['empname']))?$_POST['empname']:"";
			$sal=(isset($_POST['salary']))?$_POST['salary']:"";
			$desg=(isset($_POST['desg']))?$_POST['desg']:"";
			$city=(isset($_POST['city']))?$_POST['city']:"";
			
			mysqli_query($con,"update employee set empname='$name',
			salary='$sal',
			designation='$desg',
			city='$city' where eid=$id");
			
			echo mysqli_error($con);
			if(mysqli_affected_rows($con)>0)
			{
				setcookie("success","Employee Updated successfully",time()+2);
				header("Location:edit_emp.php?token=$id");
			}
			else
			{
				echo "Sorry! Unable to update an employee";
			}
			
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			<table class="table">
				<tr>
					<td>Emp Name</td>
					<td><input type="text" name="empname" id="empname" value="<?php echo $row['empname']?>" class="form-control"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary" value="<?php echo $row['salary']?>" class="form-control"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><select class="form-control" name="desg" id="desg">
						<option value="">--Designation--</option>
<option value="Designer" <?php if($row['designation']=="Designer") echo "selected"?> >Designer</option>
<option value="Developer"  <?php if($row['designation']=="Developer") echo "selected"?>>Developer</option>
<option value="Tester"  <?php if($row['designation']=="Tester") echo "selected"?>>Tester</option>
					</select></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city" class="form-control" value="<?php echo $row['city']?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="update" class="btn btn-primary" value="Update Employee"></td>
				</tr>
				
			</table>
		</form>
		<script>
			function validate()
			{
				
				if(document.getElementById("empname").value=="")
				{
					alert("Enter Emp Name");
					return false;
				}
				if(document.getElementById("salary").value=="")
				{
					alert("nter Salary");
					return false;
				}
				else
				{
					var sal=document.getElementById("salary").value;
					if(isNaN(sal))
					{
						alert("Salary should be in digits");
						return false;
					}
					
				}
				
			}
		</script>
				</div>
			</div>
		</div>
	
		<?php
	}
	else
	{
		echo "<P>Unable to prcess your request</p>";
	}
	
}
else
{
	echo "Unable to prcess your request";
}
include("footer.php");
?>