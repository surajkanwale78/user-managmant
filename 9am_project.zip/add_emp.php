<?php include("header.php");?>
<?php 
if(isset($_SESSION['logintrue']))
{
	?>
	<div class="container">
		<div class="row">
			<div class="col">
				<h1>Add Employee</h1>
		
		
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['add']))
		{
			$name=(isset($_POST['empname']))?$_POST['empname']:"";
			$sal=(isset($_POST['salary']))?$_POST['salary']:"";
			$desg=(isset($_POST['desg']))?$_POST['desg']:"";
			$city=(isset($_POST['city']))?$_POST['city']:"";
			
			mysqli_query($con,"insert into employee(empname,salary,city,designation) values('$name','$sal','$city','$desg')");
			echo mysqli_error($con);
			if(mysqli_affected_rows($con)>0)
			{
				setcookie("success","Employee added successfully",time()+2);
				header("Location:add_emp.php");
			}
			else
			{
				echo "Sorry! Unable to add an employee";
			}
			
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			<table class="table">
				<tr>
					<td>Emp Name</td>
					<td><input type="text" name="empname" id="empname" class="form-control"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary" class="form-control"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><select name="desg" id="desg" class="form-control">
						<option value="" >--Designation--</option>
						<option value="Designer">Designer</option>
						<option value="Developer">Developer</option>
						<option value="Tester">Tester</option>
					</select></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city" class="form-control"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="add" value="Add Employee" class="btn btn-primary"></td>
				</tr>
				
			</table>
		</form>
		<script>
			function validate()
			{
				
				if(document.getElementById("empname").value=="")
				{
					alert("Enter Emp Name");
					return false;
				}
				if(document.getElementById("salary").value=="")
				{
					alert("nter Salary");
					return false;
				}
				else
				{
					var sal=document.getElementById("salary").value;
					if(isNaN(sal))
					{
						alert("Salary should be in digits");
						return false;
					}
					
				}
				
			}
		</script>
			</div>
		</div>
	</div>
	<?php
}
else
{
	header("Location:login.php");
}
?>

<?php include("footer.php");?>