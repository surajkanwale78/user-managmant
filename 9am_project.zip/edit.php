<?php include("header.php");?>

<?php 
if(isset($_SESSION['logintrue']))
{
	$token=$_SESSION['logintrue'];
	$res=mysqli_query($con,"select profile_pic,username,mobile,state from users where token='$token'");
	$row=mysqli_fetch_assoc($res);
	?>
		<div class="container">
			<div class="row">
				<div class="col">
				
					<h1>Edit - Welcome to <?php echo $row['username'];?></h1>
				
				<?php 
				if($row['profile_pic']!="")
				{
				?>
					<img src='profiles/<?php echo $row['profile_pic']?>' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php }
				else
				{
					?>
					<img src='profiles/avatar.png' height="50" width="50">
					<a href='avatar.php'>Upload</a>
				<?php
				}
				?>
				
				
				<?php 
				
				if(isset($_COOKIE['success']))
				{
					echo $_COOKIE['success'];
				}
				
				if(isset($_POST['update']))
				{
					$uname=$_POST['uname'];
					$mob=$_POST['mobile'];
					$state=$_POST['state'];
					
					mysqli_query($con,"update users set username='$uname',
					mobile='$mob',
					state='$state' where token='$token'");
					
					if(mysqli_affected_rows($con)>0)
					{
						setcookie("success","<p>Profile Updated Succcessfully</p>",time()+2);
						header("Location:edit.php");
					}
					else
					{
						echo "<p>Sorry! Unable to Update, try again</p>";
					}
				}
				?>
				
				
		<form method="POST" action="" onsubmit="return validate()">
			<table class="table">
				<tr>
					<td>Username</td>
					<td><input type="text" name="uname" class="form-control" id="uname" value="<?php echo $row['username'];?>"></td>
				</tr>
				
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" class="form-control" value="<?php echo $row['mobile'];?>"></td>
				</tr>
				
				
				<tr>
					<td>State</td>
					<td>
<select id="state" name="state" class="form-control">
<option value="">--State--</option>
<option value="Andhrapradesh" <?php if($row['state']=="Andhrapradesh") echo "selected"?> >Andhrapradesh</option>
<option value="Telangana"  <?php if($row['state']=="Telangana") echo "selected"?>>Telangana</option>
</select>
					</td>
				</tr>
				
					
				<tr>
					<td></td>
					<td><input type="submit" name="update" value="Update" class="btn btn-success" ></td>
				</tr>
			</table>
		</form>
				
				</form>
				
				<script>
		function validate()
		{
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				return false;
			}
			
			//Mobile Validation
			if(document.getElementById("mobile").value=="")
			{
				alert("Enter Mobile Number");
				return false;
			}
			else
			{
				var mob=document.getElementById("mobile").value;
				var pat=/^[0]?[789]\d{9}$/;
				if(!pat.test(mob))
				{
					alert("Enter valid 10 digit mobile number");
					return false;
				}
			}
			
			if(document.getElementById("state").value=="")
			{
				alert("Select State");
				return false;
			}
			
		}
				</script>
				</div>
			</div>
		</div>
	<?php
	
}
else
{
	header("Location:login.php");
}
?>

<?php include("footer.php");?>